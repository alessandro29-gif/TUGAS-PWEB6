const matkulData = {
"Dasar Pemrograman": ["Prof Marco Siregar, M. T", "Dr. Philo, M.Kom."],
"Sistem Operasi": ["Ir Sulastri", "Dr. H. Ahmad Fauzi, M.Kom.", "Dr. Budi Santoso, M.T."],
"Aljabar Linear": ["Fajar Nugroho, S.Kom., M.T.", "Dr. Kevin Pratama, S.Tr.Kom., M.T.", "Rina Anggraini, S.E., M.Sc.", "Dr. Ir. Bambang Sugiarto, M.T."],
"Kalkulus 1": ["Dr. Lilis Suryani, S.Pd., M.Pd.", "Dr. Hendra Wijaya, S.Si., M.Si.", "Rian Hidayat, M.Cs."],
"Sistem Basis Data": ["Fajar Nugroho, S.Kom., M.T.", "Moh. Arif Rahman, S.Stat., M.Stat."]
};

const namaList = [
"Alessandro Almaz Filemon", "Aldo Prasetyo", "Alya Rahmawati", "Alvin Kurniawan", "Amanda Putri",
"Andini Safitri", "Andika Pratama", "Arif Hidayat", "Aren Gentong", "Bagas Saputra",
"Bella Anggraini", "Bima Wicaksono", "Citra Dewi", "Cahya Ramadhan", "Dewi Lestari",
"Dimas Nugroho", "Dina Marlina", "Eka Putra", "Eko Prabowo", "Farhan Maulana",
"Fitri Handayani", "Galih Permana", "Gita Savitri", "Hana Pertiwi", "Hendra Gunawan",
"Indah Permata", "Irfan Hakim", "Jihan Aulia", "Joko Susilo", "Kevin Sanjaya",
"Kirana Larasati", "Laras Ayu", "Lutfi Ramadhan", "Mango The Cat", "Maya Anggun",
"Muhammad Rizky", "Nadia Putri", "Naufal Fadhilah", "Nina Kartika", "Olivia Tan",
"Putra Mahendra", "Rafi Ahmad", "Rani Wulandari", "Reza Pahlevi", "Salsabila Nur",
"Satria Wibowo", "Tania Maharani", "Teguh Santoso", "Vina Oktaviani", "Yoga Pratama"
];

let students = [];
const PER_PAGE = 5;
let currentPage = 1;
let keyword = "";
let editingNim = null;
let activeIndex = -1;

const form = document.getElementById("student-form");
const fields = {
nim: document.getElementById("nim"),
nama: document.getElementById("nama"),
matkul: document.getElementById("matkul"),
dosen: document.getElementById("dosen")
};
const formTitle = document.getElementById("form-title");
const btnSimpan = document.getElementById("btn-simpan");
const tbody = document.getElementById("tbody");
const info = document.getElementById("info");
const badge = document.getElementById("badge");
const pagination = document.getElementById("pagination");
const suggestList = document.getElementById("suggest-list");

const pad = n => String(n).padStart(2, "0");
function esc(text) {
const div = document.createElement("div");
div.textContent = text;
return div.innerHTML;
}

function isiMatkul() {
Object.keys(matkulData).forEach(m => {
const opt = document.createElement("option");
opt.value = m;
opt.textContent = m;
fields.matkul.appendChild(opt);
});
}

function isiDosen(matkul, selected) {
fields.dosen.innerHTML = "";
if (!matkul) {
fields.dosen.innerHTML = '<option value="">Pilih Mata Kuliah dulu</option>';
fields.dosen.disabled = true;
return;
}
fields.dosen.innerHTML = '<option value="">Pilih Nama Dosen</option>';
matkulData[matkul].forEach(d => {
const opt = document.createElement("option");
opt.value = d;
opt.textContent = d;
fields.dosen.appendChild(opt);
});
fields.dosen.disabled = false;
if (selected) fields.dosen.value = selected;
}

fields.matkul.addEventListener("change", () => {
isiDosen(fields.matkul.value);
setError("dosen", "");
});

function highlight(text, k) {
const i = text.toLowerCase().indexOf(k.toLowerCase());
if (i === -1) return esc(text);
return esc(text.slice(0, i)) + "<mark>" + esc(text.slice(i, i + k.length)) + "</mark>" + esc(text.slice(i + k.length));
}

function getSuggestions(k) {
const low = k.toLowerCase();
const awal = namaList.filter(n => n.toLowerCase().startsWith(low));
const tengah = namaList.filter(n => !n.toLowerCase().startsWith(low) && n.toLowerCase().includes(low));
return awal.concat(tengah).slice(0, 6);
}

function hideSuggest() {
suggestList.hidden = true;
fields.nama.setAttribute("aria-expanded", "false");
activeIndex = -1;
}

function showSuggest() {
const k = fields.nama.value.trim();
if (!k) {
hideSuggest();
return;
}
const hasil = getSuggestions(k);
if (hasil.length === 0) {
suggestList.innerHTML = '<li class="no-result">Tidak ada rekomendasi, lanjut ketik manual</li>';
} else {
suggestList.innerHTML = hasil.map((n, i) => `<li role="option" data-nama="${esc(n)}" id="opt-${i}">${highlight(n, k)}</li>`).join("");
}
activeIndex = -1;
suggestList.hidden = false;
fields.nama.setAttribute("aria-expanded", "true");
}

function pilihNama(nama) {
fields.nama.value = nama;
setError("nama", "");
hideSuggest();
fields.nim.focus();
}

function setActive(idx) {
const items = suggestList.querySelectorAll("li[data-nama]");
if (!items.length) return;
activeIndex = (idx + items.length) % items.length;
items.forEach((li, i) => li.classList.toggle("active", i === activeIndex));
items[activeIndex].scrollIntoView({ block: "nearest" });
}

fields.nama.addEventListener("input", showSuggest);
fields.nama.addEventListener("focus", showSuggest);
fields.nama.addEventListener("keydown", e => {
if (suggestList.hidden) return;
if (e.key === "ArrowDown") {
e.preventDefault();
setActive(activeIndex + 1);
} else if (e.key === "ArrowUp") {
e.preventDefault();
setActive(activeIndex - 1);
} else if (e.key === "Enter" && activeIndex >= 0) {
e.preventDefault();
const li = suggestList.querySelectorAll("li[data-nama]")[activeIndex];
pilihNama(li.dataset.nama);
} else if (e.key === "Escape") {
hideSuggest();
}
});
// mousedown dipakai supaya terpilih sebelum input kehilangan fokus
suggestList.addEventListener("mousedown", e => {
const li = e.target.closest("li[data-nama]");
if (!li) return;
e.preventDefault();
pilihNama(li.dataset.nama);
});
document.addEventListener("click", e => {
if (!e.target.closest(".autocomplete")) hideSuggest();
});

// ===== Tabel =====
function getFiltered() {
const k = keyword.toLowerCase();
return students.filter(s => s.nama.toLowerCase().includes(k) || s.nim.includes(k));
}

function render() {
const data = getFiltered();
const totalPages = Math.max(1, Math.ceil(data.length / PER_PAGE));
if (currentPage > totalPages) currentPage = totalPages;
const start = (currentPage - 1) * PER_PAGE;
const rows = data.slice(start, start + PER_PAGE);

if (rows.length === 0) {
tbody.innerHTML = '<tr><td colspan="6" class="empty">' + (students.length === 0 ? "Belum ada data registrasi. Isi form di atas untuk menambahkan." : "Data tidak ditemukan.") + '</td></tr>';
} else {
tbody.innerHTML = rows.map((s, i) => `
<tr>
<td class="num">${pad(start + i + 1)}</td>
<td>${esc(s.nim)}</td>
<td><strong>${esc(s.nama)}</strong></td>
<td><span class="tag">${esc(s.matkul)}</span></td>
<td>${esc(s.dosen)}</td>
<td><div class="actions">
<button class="action edit" data-nim="${esc(s.nim)}">Edit</button>
<button class="action delete" data-nim="${esc(s.nim)}">Hapus</button>
</div></td>
</tr>`).join("");
}

badge.textContent = students.length + " Registrasi";
info.textContent = data.length
? `Menampilkan ${start + 1}–${start + rows.length} dari ${data.length} data`
: "Tidak ada data";
renderPagination(totalPages);
}

function renderPagination(totalPages) {
let html = `<button data-page="${currentPage - 1}" ${currentPage === 1 ? "disabled" : ""}>‹</button>`;
for (let p = 1; p <= totalPages; p++) {
html += `<button data-page="${p}" class="${p === currentPage ? "active" : ""}">${p}</button>`;
}
html += `<button data-page="${currentPage + 1}" ${currentPage === totalPages ? "disabled" : ""}>›</button>`;
pagination.innerHTML = html;
}

function setError(name, message) {
const group = fields[name].closest(".form-group");
document.getElementById("err-" + name).textContent = message;
group.classList.toggle("invalid", message !== "");
}

function validate() {
let valid = true;
const nim = fields.nim.value.trim();
const nama = fields.nama.value.trim();
const matkul = fields.matkul.value;
const dosen = fields.dosen.value;

let msg = nama.length < 3 ? "Nama minimal 3 karakter." : "";
setError("nama", msg);
if (msg) valid = false;

msg = "";
if (!nim) msg = "NRP wajib diisi.";
else if (!/^\d{4,12}$/.test(nim)) msg = "NRP harus angka (4–12 digit).";
else if (nim !== editingNim && students.some(s => s.nim === nim)) msg = "NRP sudah terdaftar.";
setError("nim", msg);
if (msg) valid = false;

msg = matkul ? "" : "Pilih mata kuliah dulu.";
setError("matkul", msg);
if (msg) valid = false;

msg = dosen ? "" : "Pilih nama dosen.";
setError("dosen", msg);
if (msg) valid = false;

return valid;
}

function clearForm() {
form.reset();
isiDosen("");
hideSuggest();
Object.keys(fields).forEach(n => setError(n, ""));
}

function exitEditMode() {
editingNim = null;
formTitle.textContent = "Registrasi Mata Kuliah";
btnSimpan.textContent = "Simpan data";
clearForm();
}

form.addEventListener("submit", e => {
e.preventDefault();
if (!validate()) return;
const item = {
nim: fields.nim.value.trim(),
nama: fields.nama.value.trim(),
matkul: fields.matkul.value,
dosen: fields.dosen.value
};
if (editingNim) {
const idx = students.findIndex(s => s.nim === editingNim);
students[idx] = item;
} else {
students.push(item);
currentPage = Math.ceil(getFiltered().length / PER_PAGE);
}
exitEditMode();
render();
});

document.getElementById("btn-batal").addEventListener("click", exitEditMode);
document.getElementById("btn-reset").addEventListener("click", clearForm);

tbody.addEventListener("click", e => {
const btn = e.target.closest("button");
if (!btn) return;
const nim = btn.dataset.nim;
const s = students.find(x => x.nim === nim);
if (btn.classList.contains("edit")) {
editingNim = nim;
fields.nim.value = s.nim;
fields.nama.value = s.nama;
fields.matkul.value = s.matkul;
isiDosen(s.matkul, s.dosen);
hideSuggest();
formTitle.textContent = "Edit registrasi";
btnSimpan.textContent = "Simpan perubahan";
fields.nama.focus();
hideSuggest();
}
if (btn.classList.contains("delete")) {
if (confirm(`Hapus ${s.nama} (${s.nim})?`)) {
students = students.filter(x => x.nim !== nim);
if (editingNim === nim) exitEditMode();
render();
}
}
});

document.getElementById("search").addEventListener("input", e => {
keyword = e.target.value.trim();
currentPage = 1;
render();
});

pagination.addEventListener("click", e => {
const btn = e.target.closest("button");
if (!btn || btn.disabled) return;
currentPage = Number(btn.dataset.page);
render();
});

isiMatkul();
render();
