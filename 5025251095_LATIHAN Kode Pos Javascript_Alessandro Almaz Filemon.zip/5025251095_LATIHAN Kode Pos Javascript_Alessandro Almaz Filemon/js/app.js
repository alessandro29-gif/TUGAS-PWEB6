const dataKodePos = {
"Jawa Barat": {
"Kota Bandung": { "Coblong": "40132", "Bandung Wetan": "40114", "Sumur Bandung": "40111", "Cibeunying Kaler": "40122", "Lengkong": "40261" },
"Kabupaten Bandung": { "Soreang": "40911", "Baleendah": "40375", "Banjaran": "40377", "Cileunyi": "40393", "Dayeuhkolot": "40258" },
"Kota Bogor": { "Bogor Tengah": "16121", "Bogor Utara": "16151", "Bogor Selatan": "16131", "Bogor Timur": "16141", "Bogor Barat": "16111" },
"Kabupaten Bekasi": { "Cikarang Pusat": "17530", "Cikarang Selatan": "17532", "Cikarang Barat": "17531", "Tambun Selatan": "17510", "Tambun Utara": "17511" },
"Kota Depok": { "Pancasoran Mas": "16431", "Beji": "16421", "Sukmajaya": "16412", "Cimanggis": "16451", "Cinere": "16514" }
},
"Jawa Timur": {
"Kota Surabaya": { "Genteng": "60275", "Tegalsari": "60262", "Gubeng": "60281", "Sukolilo": "60111", "Mulyorejo": "60112" },
"Kabupaten Sidoarjo": { "Sidoarjo": "61211", "Candi": "61271", "Waru": "61256", "Taman": "61257", "Krian": "61262" },
"Kabupaten Malang": { "Kepanjen": "65163", "Singosari": "65153", "Lawang": "65211", "Dau": "65151", "Pujon": "65391" },
"Kota Malang": { "Klojen": "65111", "Lowokwaru": "65141", "Blimbing": "65121", "Sukun": "65147", "Kedungkandang": "65137" },
"Kabupaten Banyuwangi": { "Banyuwangi": "68411", "Giri": "68423", "Rogojampi": "68462", "Genteng": "68465", "Kalipuro": "68421" }
},
"Jawa Tengah": {
"Kota Semarang": { "Semarang Tengah": "50131", "Semarang Selatan": "50241", "Semarang Barat": "50141", "Semarang Timur": "50121", "Banyumanik": "50269" },
"Kota Surakarta": { "Banjarsari": "57131", "Jebres": "57126", "Laweyan": "57141", "Pasar Kliwon": "57118", "Serengan": "57151" },
"Kabupaten Banyumas": { "Purwokerto Timur": "53111", "Purwokerto Barat": "53131", "Purwokerto Utara": "53121", "Purwokerto Selatan": "53141", "Banyumas": "53192" },
"Kabupaten Magelang": { "Muntilan": "56411", "Borobudur": "56553", "Mertoyudan": "56172", "Mungkid": "56512", "Secang": "56195" },
"Kabupaten Kudus": { "Kudus Kota": "59311", "Jati": "59347", "Bae": "59321", "Gebog": "59333", "Kaliwungu": "59371" }
},
"DKI Jakarta": {
"Kota Jakarta Pusat": { "Menteng": "10310", "Gambir": "10110", "Tanah Abang": "10210", "Kemayoran": "10610", "Senen": "10410" },
"Kota Jakarta Selatan": { "Kebayoran Baru": "12110", "Kebayoran Lama": "12210", "Cilandak": "12430", "Mampang Prapatan": "12790", "Setiabudi": "12910" },
"Kota Jakarta Barat": { "Grogol Petamburan": "11440", "Kebon Jeruk": "11530", "Palmerah": "11480", "Cengkareng": "11730", "Kembangan": "11610" },
"Kota Jakarta Timur": { "Jatinegara": "13310", "Pulo Gadung": "13220", "Cipayung": "13840", "Duren Sawit": "13440", "Kramat Jati": "13510" },
"Kota Jakarta Utara": { "Penjaringan": "14440", "Tanjung Priok": "14310", "Kelapa Gading": "14240", "Pademangan": "14420", "Koja": "14210" }
},
"Bali": {
"Kota Denpasar": { "Denpasar Selatan": "80221", "Denpasar Barat": "80119", "Denpasar Utara": "80111", "Denpasar Timur": "80237", "Denpasar Barat (Pemecutan)": "80112" },
"Kabupaten Badung": { "Kuta": "80361", "Kuta Utara": "80363", "Kuta Selatan": "80362", "Mengwi": "80351", "Abiansemal": "80352" },
"Kabupaten Gianyar": { "Ubud": "80571", "Gianyar": "80511", "Sukawati": "80582", "Blahbatuh": "80581", "Tampaksiring": "80552" },
"Kabupaten Buleleng": { "Singaraja / Buleleng": "81111", "Banjar": "81152", "Seririt": "81153", "Sawan": "81171", "Sukasada": "81161" },
"Kabupaten Tabanan": { "Tabanan": "82111", "Kediri": "82121", "Baturiti": "82191", "Marga": "82181", "Penebel": "82152" }
},
"Nusa Tenggara Barat": {
"Kota Mataram": { "Mataram": "83121", "Ampenan": "83511", "Cakranegara": "83231", "Sekarbela": "83115", "Selaparang": "83122" },
"Kabupaten Lombok Barat": { "Gerung": "83363", "Batu Layar": "83355", "Narmada": "83371", "Kediri": "83362", "Lembar": "83364" },
"Kabupaten Lombok Tengah": { "Praya": "83511", "Pujut": "83573", "Praya Barat": "83572", "Praya Timur": "83581", "Kopang": "83553" },
"Kabupaten Lombok Timur": { "Selong": "83611", "Masbagik": "83661", "Labuhan Haji": "83616", "Aikmel": "83653", "Pringgabaya": "83655" },
"Kota Bima": { "Rasanae Barat": "84111", "Rasanae Timur": "84114", "Mpunda": "84117", "Raba": "84113", "Asakota": "84118" }
},
"Nusa Tenggara Timur": {
"Kota Kupang": { "Oebobo": "85111", "Maulafa": "85142", "Kelapa Lima": "85228", "Alak": "85231", "Kota Raja": "85115" },
"Kabupaten Manggarai Barat": { "Komodo": "86754", "Sano Nggoang": "86753", "Lembor": "86752", "Mbeliling": "86755", "Macang Pacar": "86761" },
"Kabupaten Sikka": { "Alok": "86111", "Alok Barat": "86113", "Alok Timur": "86118", "Nita": "86151", "Maumere / Lela": "86161" },
"Kabupaten Ende": { "Ende Selatan": "86311", "Ende Utara": "86312", "Ende Timur": "86313", "Ende Tengah": "86318", "Ndjona": "86371" },
"Kabupaten Timor Tengah Selatan": { "Kota Soe": "85511", "Amanuban Barat": "85551", "Amanuban Selatan": "85562", "Amanatun Utara": "85571", "Mollo Utara": "85552" }
}
};

const form = document.getElementById("search-form");
const fields = {
provinsi: document.getElementById("provinsi"),
kota: document.getElementById("kota"),
kecamatan: document.getElementById("kecamatan")
};
const result = document.getElementById("result");
const info = document.getElementById("info");

function esc(text) {
const div = document.createElement("div");
div.textContent = text;
return div.innerHTML;
}

function isiOpsi(select, items, placeholder) {
select.innerHTML = '<option value="">' + placeholder + '</option>';
items.forEach(item => {
const opt = document.createElement("option");
opt.value = item;
opt.textContent = item;
select.appendChild(opt);
});
}

function setError(name, message) {
const group = fields[name].closest(".form-group");
document.getElementById("err-" + name).textContent = message;
group.classList.toggle("invalid", message !== "");
}

function isiProvinsi() {
isiOpsi(fields.provinsi, Object.keys(dataKodePos), "Pilih Provinsi");
}

function resetKota() {
fields.kota.innerHTML = '<option value="">Pilih Provinsi terlebih dahulu!</option>';
fields.kota.disabled = true;
}

function resetKecamatan() {
fields.kecamatan.innerHTML = '<option value="">Pilih Kabupaten/Kota terlebih dahulu!</option>';
fields.kecamatan.disabled = true;
}

fields.provinsi.addEventListener("change", () => {
const prov = fields.provinsi.value;
resetKecamatan();
if (!prov) {
resetKota();
} else {
isiOpsi(fields.kota, Object.keys(dataKodePos[prov]), "Pilih Kabupaten/Kota");
fields.kota.disabled = false;
}
setError("provinsi", "");
setError("kota", "");
setError("kecamatan", "");
});

fields.kota.addEventListener("change", () => {
const prov = fields.provinsi.value;
const kota = fields.kota.value;
if (!kota) {
resetKecamatan();
} else {
isiOpsi(fields.kecamatan, Object.keys(dataKodePos[prov][kota]), "Pilih Kecamatan");
fields.kecamatan.disabled = false;
}
setError("kota", "");
setError("kecamatan", "");
});

fields.kecamatan.addEventListener("change", () => setError("kecamatan", ""));

function validate() {
let valid = true;
const pesan = {
provinsi: "Pilih provinsi dulu.",
kota: "Pilih kabupaten/kota dulu.",
kecamatan: "Pilih kecamatan dulu."
};
Object.keys(fields).forEach(name => {
const msg = fields[name].value ? "" : pesan[name];
setError(name, msg);
if (msg) valid = false;
});
return valid;
}

function tampilkanHasil(prov, kota, kec) {
const pos = dataKodePos[prov] && dataKodePos[prov][kota] && dataKodePos[prov][kota][kec];
if (!pos) {
info.textContent = "Hasil Pencarian Kode Pos tidak ditemukan.";
result.innerHTML = "";
return;
}
info.textContent = "Hasil Pencarian Kode Pos ditemukan!";
result.innerHTML = `
<div class="result-item">
<div class="result-head">${esc(kec)}</div>
<div class="result-body">
<span class="zip">${esc(pos)}</span>
<p>Kode pos <strong>${esc(pos)}</strong> untuk daerah Kecamatan ${esc(kec)}, ${esc(kota)}, Provinsi ${esc(prov)}.</p>
</div>
</div>`;
}

form.addEventListener("submit", e => {
e.preventDefault();
if (!validate()) return;
tampilkanHasil(fields.provinsi.value, fields.kota.value, fields.kecamatan.value);
});

document.getElementById("btn-reset").addEventListener("click", () => {
form.reset();
resetKota();
resetKecamatan();
Object.keys(fields).forEach(n => setError(n, ""));
result.innerHTML = "";
info.textContent = "Belum ada pencarian. Pilih daerah di atas lalu tekan tombol Cari.";
});

isiProvinsi();
